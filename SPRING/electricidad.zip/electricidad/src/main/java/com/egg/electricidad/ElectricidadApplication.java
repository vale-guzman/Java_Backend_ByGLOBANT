package com.egg.electricidad;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ElectricidadApplication {

	public static void main(String[] args) {
		SpringApplication.run(ElectricidadApplication.class, args);
	}

}
